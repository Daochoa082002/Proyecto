import dash
from dash import dcc
from dash import html
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go

#external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
#app = dash.Dash(__name__, external_stylesheets=external_stylesheets)

#app = dash.Dash(__name__)

app = dash.Dash()

df_datos = pd.read_csv('Datos_trabajo2.csv', 
                 sep = ','
                 )
df_datos = df_datos.drop(["Unnamed: 0"], axis=1)

df_datos2 = pd.read_csv("Datos_mapa2.csv", 
                 sep = ',')
df_datos2 = df_datos2.drop(["Unnamed: 0"], axis=1)

## Visualizacion 1

vis_1 = px.treemap(df_datos, 
                 path=['Income_Group','Country Name']
                )
## Visualizacion 2

df_proyecto_2 = pd.pivot_table(df_datos, 
                                values=['2000',"2001","2002","2003","2004","2005","2006","2007","2008","2009",
                                       "2010","2011","2012","2013","2014","2015","2016","2017","2018","2019","2020"], 
                                index=["Indicator Name"],
                                    columns=["Sexo_o_clase"], 
                                aggfunc=np.mean)
df_proyecto_2 = pd.DataFrame(df_proyecto_2)
df_proyecto_2 = df_proyecto_2.transpose().reset_index()
df_proyecto_2 = df_proyecto_2.rename(columns = {"Sexo_o_clase" : "Clase"})
df_proyecto_2 = df_proyecto_2.rename(columns = {"level_0" : "Año"})

vis_2 = px.line(df_proyecto_2, x="Año", y="Porcentaje de niños economicamente activos", color='Clase')
vis_2.update_layout(margin = dict(t=50, l=25, r=25, b=25))

## visualizacion 3

df_proyecto_3 = pd.pivot_table(df_datos, 
                                values=['2000',"2001","2002","2003","2004","2005","2006","2007","2008","2009",
                                       "2010","2011","2012","2013","2014","2015","2016","2017","2018","2019","2020"], 
                                index=["Indicator Name"],
                                    columns=["Sexo_o_clase"], 
                                aggfunc=np.mean)
df_proyecto_3 = pd.DataFrame(df_proyecto_3)
df_proyecto_3 = df_proyecto_3.transpose().reset_index()
df_proyecto_3 = df_proyecto_3.rename(columns = {"Sexo_o_clase" : "Clase"})
df_proyecto_3 = df_proyecto_3.rename(columns = {"level_0" : "Año"})
df_proyecto_3 = df_proyecto_3.rename(columns = {"Porcentaje de niños economicamente activos" : "Fuerza Laboral"})
df_proyecto_3 = df_proyecto_3.rename(columns = {"Porcentaje de niños que solo trabajan" : "Solo trabajan"})
df_proyecto_3 = df_proyecto_3.rename(columns = {"Porcentaje de niños que solo trabajan y estudian" : "Trabajan y Estudian"})

vis_3 = px.scatter_matrix(df_proyecto_3, dimensions=["Fuerza Laboral", "Solo trabajan", "Trabajan y Estudian"], color="Clase")
vis_3.update_layout(margin = dict(t=10, l=25, r=25, b=25))

## visualizacion 4

df_proyecto_4 = pd.pivot_table(df_datos, 
                                values=['2000',"2001","2002","2003","2004","2005","2006","2007","2008","2009",
                                       "2010","2011","2012","2013","2014","2015","2016","2017","2018","2019","2020"], 
                                index=["Indicator Name"],
                                    columns=["Income_Group","Sexo_o_clase"], 
                                aggfunc=np.mean)
df_proyecto_4 = pd.DataFrame(df_proyecto_4)
df_proyecto_4 = df_proyecto_4.transpose().reset_index()
df_proyecto_4 = df_proyecto_4.rename(columns = {"Income_Group" : "Clasificacion de paises por ingreso"})
vis_4 = px.scatter(df_proyecto_4, x="Porcentaje de niños que solo trabajan y estudian", y="Porcentaje de niños economicamente activos",
         size="Porcentaje de niños economicamente activos", color="Clasificacion de paises por ingreso",
                  size_max=60)
vis_4.update_layout(margin = dict(t=10, l=25, r=25, b=25))

## visualizacion 5

df_proyecto_5 = pd.pivot_table(df_datos, 
                                values=['2000',"2001","2002","2003","2004","2005","2006","2007","2008","2009",
                                       "2010","2011","2012","2013","2014","2015","2016","2017","2018","2019","2020"], 
                                index=["Indicator Name"],
                                    columns=["Income_Group","Sexo_o_clase","Region"], 
                                aggfunc=np.mean)
df_proyecto_5 = pd.DataFrame(df_proyecto_5)
df_proyecto_5 = df_proyecto_5.transpose().reset_index()
vis_5 = px.histogram(df_proyecto_5, x="Porcentaje de niños que solo trabajan", color="Region")
vis_5.update_layout(margin = dict(t=00, l=25, r=25, b=25))

## visualizacion 6

df_proyecto_6 = pd.pivot_table(df_datos2, 
                                values=['2000',"2001","2002","2003","2004","2005","2006","2007","2008","2009",
                                       "2010","2011","2012","2013","2014","2015","2016","2017","2018","2019","2020"], 
                                index=["Indicator Name"],
                                    columns=['Country Name',"Income_Group","Region","id","lat","lon"], 
                                aggfunc=np.mean)
df_proyecto_6 = pd.DataFrame(df_proyecto_6)
df_proyecto_6 = df_proyecto_6.transpose().reset_index()
df_proyecto_6 = df_proyecto_6.rename(columns = {"Income_Group" : "Clasificacion de paises segun sus ingresos"})
df_proyecto_6 = df_proyecto_6.rename(columns = {"level_0" : "Año"})

px.set_mapbox_access_token("pk.eyJ1IjoiZGFvY2hvYTA4MjAwMiIsImEiOiJjbDFtdzZraTIwajdnM2p1a3Q1d2EwemtjIn0.HKAYriGAUUaNXeVBc9Bxjg")
vis_6 = px.scatter_mapbox(df_proyecto_6,
                        lat='lat',
                        lon='lon',
                        hover_name='Country Name',
                        zoom=3,
                        color="Clasificacion de paises segun sus ingresos",
                        size="Porcentaje de niños economicamente activos",
                        animation_frame="Año", 
                        center = {"lat": 4.570868, "lon": -74.297333})
vis_6.update_layout(
        title_text = 'Porcentaje de niños economicamente activos',
        showlegend = True,
    )
vis_6.update_layout(margin = dict(t=10, l=50, r=50, b=50))

app.layout = html.Div(
    children=[
        html.H1(children="Situacion de Niños y Niñas en la Fuerza Laboral",
            style = {
                        'textAlign': 'center',
            }),
        html.H2(children="Clasificacion de los Paises segun su nivel de ingreso y Region"),
        html.P(
            children="En ésta visualización se puede observar "
            "la distribución de paises segun su ingreso segun el Banco Mundial. "
            ),
    html.Div(dcc.Graph(
                id='example-graph-1',
                figure=vis_1,
                style={'height': 1000, 'width': 1700})
            ),

    ## vis2 ###

    html.Div([
        html.Div([
            html.H2(children='Variacion de Porcentajes por años'),#
            html.Div(children='''
                porcentajes
            '''),
            dcc.Graph(
                id='example-graph-2',
                figure=vis_2
            ),  
        ], className='six columns'),
    ## vis3 ##
        
        html.Div([
            html.H2(children='Porcentajes de niños que trabajan y estudian'),
            html.Div(children='''
                porcentajes
            '''),
            dcc.Graph(
                id='example-graph-3',
                figure=vis_3
            ), 
        ], className='six columns'),
    ], className='row'),    

    ## vis4 ## 

    html.Div([    
        html.Div([
            html.H2(children='Porcentajes de niños que trabajan y estudian'),
            html.Div(children='''
                porcentajes
            '''),
            dcc.Graph(
                id='example-graph-4',
                figure=vis_4
            ), 
        ], className='six columns'),    

    ## vis5 ##
        
        html.Div([
            html.H2(children='Histograma de Porcentajes'),
            html.Div(children='''
                porcentajes
            '''),
            dcc.Graph(
                id='example-graph-5',
                figure=vis_5
            ), 
        ], className='six columns'), 
    ], className='row'),    

    ## vis 6 ##
    
    html.Div([
        html.H2(children='Mapa'),
        html.Div(children='''
            porcentajes
        '''),
        dcc.Graph(
            id='example-graph-6',
            figure=vis_6,
            style={'height': 1000, 'width': 1700}
        ), 
    ]), 

])  
    

if __name__ == "__main__":
     app.run_server(debug=True)